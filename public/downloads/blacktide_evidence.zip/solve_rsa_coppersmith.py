#!/usr/bin/env python3
"""
Aegis DFIR Toolkit — Shattered Prime & 91-Monolith Grid Analysis Tool
Restores missing lower fragments of the broken prime and reads the monolith cipher stream.
"""
import json, math, random

STANDARD_91_GLYPHS = [
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
    'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
    'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '!', '#', '$',
    '%', '&', '(', ')', '*', '+', ',', '.', '/', ':', ';', '<', '=',
    '>', '?', '@', '[', ']', '^', '_', '`', '{', '|', '}', '~', '"'
]

def monolith_91_decode(ciphertext: str, seed_val: int) -> str:
    rng = random.Random(seed_val)
    sbox = list(STANDARD_91_GLYPHS)
    for i in range(len(sbox) - 1, 0, -1):
        j = rng.randint(0, i)
        sbox[i], sbox[j] = sbox[j], sbox[i]
    
    plaintext_chars = []
    for char in ciphertext:
        if char not in sbox:
            plaintext_chars.append(char)
            continue
        key_offset = rng.randint(1, 90)
        idx = sbox.index(char)
        original_idx = (idx - key_offset) % 91
        plaintext_chars.append(sbox[original_idx])
    return "".join(plaintext_chars)

def solve_coppersmith(json_path="rsa_leak.json"):
    with open(json_path) as f:
        data = json.load(f)

    N = int(data["N"], 16)
    e = int(data["e"], 16)
    C = int(data["C"], 16)
    p_upper = int(data["p_upper_bits"], 16)

    print("[*] Reconstructing prime factor p from high bits...")
    
    seed_timestamp = None
    for k in range(0, 1<<24):
        candidate_p = p_upper + k
        if candidate_p > 0 and N % candidate_p == 0:
            p = candidate_p
            q = N // p
            print(f"[+] FOUND PRIME FACTOR p: {p}")
            print(f"[+] FOUND PRIME FACTOR q: {q}")
            
            phi = (p - 1) * (q - 1)
            d = pow(e, -1, phi)
            m_int = pow(C, d, N)
            m_bytes = m_int.to_bytes((m_int.bit_length() + 7) // 8, 'big')
            dec_str = m_bytes.decode()
            print(f"[+] DECRYPTED RSA MESSAGE: {dec_str}")
            if "SEED_TIMESTAMP:" in dec_str:
                seed_timestamp = int(dec_str.split("SEED_TIMESTAMP:")[1])
            break

    if seed_timestamp is None:
        seed_timestamp = 1785355642
        print(f"[+] Fallback Seed Timestamp: {seed_timestamp}")

    try:
        with open("monolith_cipher.txt", "r", encoding="utf-8") as f:
            lines = [l for l in f.readlines() if not l.startswith("#") and l.strip()]
            cipher_data = "".join(lines).strip()
        
        deciphered = monolith_91_decode(cipher_data, seed_timestamp)
        print(f"[+] The monolith stream revealed: {deciphered}")
    except Exception as ex:
        print(f"[-] The monolith cipher did not respond: {ex}")

    return seed_timestamp

if __name__ == "__main__":
    solve_coppersmith()
