#!/usr/bin/env python3
"""
Aegis Secure — Sealed Entry Vessel Opener
Usage: python3 decrypt_entry.py <KEY>
"""
import sys, hashlib
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

if len(sys.argv) < 2:
    print("Usage: python3 decrypt_entry.py <KEY>")
    print("[The key to this vessel was hidden in the clock that Black Tide wound before they left.]")
    sys.exit(1)

passphrase = sys.argv[1].strip()
key_bytes = hashlib.sha256(passphrase.encode('utf-8')).digest()

try:
    with open("encrypted_entry.bin", "rb") as f:
        raw = f.read()
    iv = raw[:16]
    ciphertext = raw[16:]
    cipher = Cipher(algorithms.AES(key_bytes), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    padded = decryptor.update(ciphertext) + decryptor.finalize()
    pad_len = padded[-1]
    plaintext = padded[:-pad_len].decode('utf-8')
    print("\n[+] The sealed entry vessel opened. Contents:\n")
    print(plaintext)
except Exception as e:
    print(f"[-] The vessel did not open: {e}")
